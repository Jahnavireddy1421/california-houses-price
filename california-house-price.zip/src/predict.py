"""Load saved model and run predictions from CSV."""
import sys
import pandas as pd
import joblib
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE_DIR / "models" / "house_price_model.pkl"

EXPECTED_COLS = [
    'MedInc','HouseAge','AveRooms','AveBedrms',
    'Population','AveOccup','Latitude','Longitude'
]

def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Run `python -m src.train` first.")
    return joblib.load(MODEL_PATH)

def predict_from_csv(csv_path: str):
    df = pd.read_csv(csv_path)
    missing = [c for c in EXPECTED_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns in input CSV: {missing}")
    model = load_model()
    preds = model.predict(df[EXPECTED_COLS]) * 100000
    out = df.copy()
    out['PredictedPriceUSD'] = preds
    return out

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python -m src.predict <input.csv>")
        sys.exit(1)
    input_csv = sys.argv[1]
    result = predict_from_csv(input_csv)
    out_path = Path(input_csv).with_suffix(".predicted.csv")
    result.to_csv(out_path, index=False)
    print("Predictions saved to", out_path)
