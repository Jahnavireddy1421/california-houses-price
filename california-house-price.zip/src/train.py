"""Train model on California Housing dataset and save to models/."""
import json
import joblib
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_DIR = BASE_DIR / "models"
DATA_DIR = BASE_DIR / "data"
MODEL_DIR.mkdir(exist_ok=True, parents=True)
DATA_DIR.mkdir(exist_ok=True, parents=True)

def main():
    print("Loading California Housing dataset...")
    housing = fetch_california_housing(as_frame=True)
    X = housing.data
    y = housing.target

    # Save raw data for reference
    raw_path = DATA_DIR / "california_housing_raw.csv"
    pd.concat([X, y.rename("MedHouseVal")], axis=1).to_csv(raw_path, index=False)
    print(f"Saved raw data to {raw_path}")

    X_train, X_test, Y_train, Y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    print("Training model...")
    pipe = Pipeline([
        ('scaler', StandardScaler()),
        ('rf', RandomForestRegressor(n_estimators=300, random_state=42, n_jobs=-1))
    ])
    pipe.fit(X_train, Y_train)

    print("Evaluating...")
    preds = pipe.predict(X_test)
    rmse = float(np.sqrt(mean_squared_error(Y_test, preds)))
    mae = float(mean_absolute_error(Y_test, preds))
    r2 = float(r2_score(Y_test, preds))

    metrics = {
        "RMSE": rmse,
        "MAE": mae,
        "R2": r2,
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
        "random_state": 42
    }

    with open(MODEL_DIR / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    joblib.dump(pipe, MODEL_DIR / "house_price_model.pkl")

    print("Done!")
    print("Model saved to:", MODEL_DIR / "house_price_model.pkl")
    print("Metrics:", metrics)

if __name__ == "__main__":
    main()
