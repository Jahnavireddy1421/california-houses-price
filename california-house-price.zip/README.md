# California House Price Prediction

End-to-end ML mini-project using Scikit-learn's **California Housing** dataset.

## What This Project Does
- Trains a RandomForest regression pipeline
- Predicts median house value (in USD)
- Interactive web UI using Streamlit

## Quick Start

### 1. Clone & Install
```bash
git clone <your-repo-url>.git
cd california-house-price
pip install -r requirements.txt
```

### 2. Train Model
```bash
python -m src.train
```

### 3. Run App
```bash
cd app
streamlit run streamlit_app.py
```

### 4. Batch Predict
Prepare CSV with columns:
`MedInc,HouseAge,AveRooms,AveBedrms,Population,AveOccup,Latitude,Longitude`

```bash
python -m src.predict your_data.csv
```

Output: `your_data.predicted.csv`

---

**Dataset Units:** Target is in 100,000 USD units; the app multiplies by 100000 to report dollars.

Enjoy! 🏡
